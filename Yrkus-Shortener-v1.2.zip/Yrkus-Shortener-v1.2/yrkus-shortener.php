<?php
/**
 * Plugin Name: Yrkus API Shortener
 * Description: Generates secure, short links for posts and pages using the external Yrkus API.
 * Version: 1.2
 * Author: Yrkus
 * Author URI: https://www.yrkus.com/
 * License: GPL2
 */

// Define constants
if ( ! defined( 'YRKUS_PLUGIN_DIR' ) ) {
    define( 'YRKUS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'YRKUS_PLUGIN_URL' ) ) {
    define( 'YRKUS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}

// Check if the admin class exists and include the file
if ( is_admin() ) {
    require_once YRKUS_PLUGIN_DIR . 'admin/class-yrkus-admin.php';
    
    // Initialize the Admin Class
    function yrkus_run_admin() {
        $plugin = new Yrkus_Admin();
    }
    yrkus_run_admin();
}