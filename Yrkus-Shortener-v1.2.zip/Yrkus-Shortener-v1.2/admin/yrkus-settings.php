<div class="wrap">
    <h1>Yrkus Shortener Settings</h1>
    <form method="post" action="options.php">
        <?php
        // Output the settings fields defined in init_settings
        settings_fields( 'yrkus-settings' );
        do_settings_sections( 'yrkus-settings' );
        submit_button();
        ?>
    </form>
</div>