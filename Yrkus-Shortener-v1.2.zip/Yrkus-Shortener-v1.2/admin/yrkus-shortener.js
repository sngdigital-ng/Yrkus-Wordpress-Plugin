/**
 * Handles the generation of Yrkus short links via AJAX in the WP Admin.
 */
jQuery(document).ready(function($) {
    
    // --- Global Copy Handler ---
    function handleCopy(e) {
        e.preventDefault();
        
        // Find the closest parent link container
        const $linkContainer = $(this).closest('.yrkus-output-field, div[id^="yrkus-list-link-"]'); 
        const linkId = $(this).data('link-id');
        
        // Find the link tag inside the container using the dynamic ID
        const $linkElement = $('#' + linkId).find('a.yrkus-link-text, a').first();
        const shortUrl = $linkElement.text().trim();
        
        if (shortUrl) {
             if (navigator.clipboard) {
                navigator.clipboard.writeText(shortUrl).then(function() {
                    // Temporarily update button/span text to show success
                    const $copyIndicator = $(e.target).is('button') ? $(e.target) : $(e.target).parent('button');
                    $copyIndicator.attr('data-original-html', $copyIndicator.html()).html('<span class="dashicons dashicons-yes"></span> Copied!');
                    
                    setTimeout(function() {
                        $copyIndicator.html($copyIndicator.attr('data-original-html'));
                    }, 1500);
                });
            } else {
                alert('Copy failed. Please copy the link manually.');
            }
        }
    }

    // --- Main Generate Logic ---
    function handleGenerate(e) {
        e.preventDefault();

        const $button = $(e.currentTarget);
        const postId = $button.data('post-id');
        const postUrl = $button.data('post-url');
        
        const isListBox = $button.hasClass('yrkus-generate-list-button');
        
        // --- CRITICAL FIX: Robust Selectors ---
        // Find the elements *relative* to the button that was clicked.
        let $outputArea, $errorArea;

        if (isListBox) {
            // We are in the post list table. Find the <td> and the status <div>
            const $cell = $button.closest('td');
            $outputArea = $cell.find('div[id^="yrkus-list-link-"]'); // This is created on success
            $errorArea = $cell.find('.yrkus-list-status');
        } else {
            // We are in the meta box. Find the elements by their static IDs.
            const $metaBox = $button.closest('#yrkus-shortlink-status');
            $outputArea = $metaBox.find('p[id^="yrkus-link-output-"]'); // Target the dynamic output <p>
            $errorArea = $metaBox.find('#yrkus-error-message');
        }
        // --- END FIX ---
        
        // 1. Reset UI and disable button
        if (isListBox) {
            // List View: Clear previous status and hide button immediately
            $button.closest('td').find('.yrkus-output-field').remove(); 
            $errorArea.html('Generating...').removeClass('hidden yrkus-error-field').addClass('yrkus-list-status');
            $button.hide();
        } else {
            // Meta Box View: Reset output fields
            $outputArea.addClass('hidden').empty();
            $errorArea.addClass('hidden').empty();
        }

        $button.prop('disabled', true).text('Generating...');

        if (!postUrl) {
            $errorArea.text('Error: Could not retrieve the current post URL.').removeClass('hidden').addClass('yrkus-error-field');
            $button.prop('disabled', false).text('Generate Yrkus Link');
            return;
        }

        // 2. Prepare data for WordPress AJAX handler
        const data = {
            'action': 'yrkus_generate_link', 
            'security': Yrkus_Admin_Vars.nonce, 
            'post_url': postUrl, 
            'post_id': postId 
        };

        // 3. Send request
        $.post(Yrkus_Admin_Vars.ajax_url, data)
            .done(function(response) {
                
                if (response.success && response.data && response.data.short_url) {
                    const shortUrl = response.data.short_url;
                    
                    // The link ID must be unique per post/page
                    const linkIdAttr = 'yrkus-link-output-' + postId; 
                    
                    // --- Construct the final HTML output ---
                    const shortLinkOutput = `
                        <a href="${shortUrl}" target="_blank" class="yrkus-link-text">${shortUrl}</a>
                        <button class="button button-small yrkus-copy-button" data-link-id="${linkIdAttr}">
                           <span class="dashicons dashicons-admin-page"></span> Copy
                        </button>
                    `;
                    
                    if (isListBox) {
                        // B1. Update List Table row
                        const $newLinkContainer = $(`<div id="${linkIdAttr}" class="yrkus-output-field"></div>`).html(shortLinkOutput);
                        $button.closest('td').empty().append($newLinkContainer);
                        $newLinkContainer.find('.yrkus-copy-button').trigger('click');

                    } else {
                        // B2. Update Meta Box
                        $outputArea.attr('id', linkIdAttr).html('<span class="dashicons dashicons-external"></span> Link Created: <br>' + shortLinkOutput);
                        $outputArea.removeClass('hidden');
                        $errorArea.addClass('hidden');
                        $outputArea.find('.yrkus-copy-button').trigger('click'); 
                        $button.prop('disabled', false).text('Generate Yrkus Link');
                    }
                
                } else {
                    // Handle API or server-side error
                    const message = response.data?.message || 'Unknown generation error. Check settings.';
                    $errorArea.text(message).removeClass('hidden').addClass('yrkus-error-field');
                    
                    if (!isListBox) {
                        $button.prop('disabled', false).text('Generate Yrkus Link'); 
                    } else {
                        $button.show(); 
                        $errorArea.html(message); // Show error in list status
                    }
                }
            })
            .fail(function(xhr) {
                // Handle network failure or fatal PHP error
                $errorArea.text('Network Error: Check console for status ' + xhr.status).removeClass('hidden').addClass('yrkus-error-field');
                
                if (!isListBox) {
                    $button.prop('disabled', false).text('Generate Yrkus Link');
                } else {
                    $button.show();
                    $errorArea.html('Network Error. Please try again.');
                }
            });
    }

    // --- Event Bindings ---
    
    // 1. Meta Box Button binding
    // We target the static ID from the PHP
    $('#yrkus-generate-button').on('click', handleGenerate); 

    // 2. List Table Button binding (uses delegation since buttons are dynamically loaded)
    $(document).on('click', '.yrkus-generate-list-button', handleGenerate);
    
    // 3. Copy Button binding (uses delegation for all copy buttons)
    $(document).on('click', '.yrkus-copy-button', handleCopy);
});