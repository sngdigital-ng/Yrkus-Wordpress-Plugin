<?php
/**
 * Handles all admin-facing functionality for the Yrkus Shortener plugin.
 */
class Yrkus_Admin {

    public function __construct() {
        // Hooks for settings
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'init_settings' ) );

        // Hooks for post/page meta box
        add_action( 'add_meta_boxes', array( $this, 'add_shortlink_meta_box' ) );

        // Hooks for scripts and styles
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

        // Hooks for AJAX (communication with the external API)
        add_action( 'wp_ajax_yrkus_generate_link', array( $this, 'ajax_generate_link' ) );

        // --- NEW: Hooks for Post/Page List Table ---
        add_filter('manage_post_posts_columns', array($this, 'add_post_list_column'));
        add_action('manage_post_posts_custom_column', array($this, 'render_post_list_column'), 10, 2);
        add_filter('manage_page_posts_columns', array($this, 'add_post_list_column'));
        add_action('manage_page_posts_custom_column', array($this, 'render_post_list_column'), 10, 2);
        // --- END NEW HOOKS ---
    }

    // --- Settings Page Setup (Unmodified) ---

    public function add_settings_page() {
        add_options_page(
            'Yrkus API Settings',
            'Yrkus Shortener',
            'manage_options',
            'yrkus-settings',
            array( $this, 'render_settings_page' )
        );
    }

    public function init_settings() {
        // Register a new setting section
        add_settings_section(
            'yrkus_api_section',
            'API Configuration',
            null,
            'yrkus-settings'
        );

        // Register the API Key field
        add_settings_field(
            'yrkus_api_key',
            'Yrkus API Key',
            array( $this, 'render_api_key_field' ),
            'yrkus-settings',
            'yrkus_api_section'
        );
        register_setting( 'yrkus-settings', 'yrkus_api_key' );

        // Register the API Base URL field
        add_settings_field(
            'yrkus_api_url',
            'Base API URL',
            array( $this, 'render_api_url_field' ),
            'yrkus-settings',
            'yrkus_api_section'
        );
        register_setting( 'yrkus-settings', 'yrkus_api_url' );
    }

    public function render_settings_page() {
        include YRKUS_PLUGIN_DIR . 'admin/yrkus-settings.php';
    }

    public function render_api_key_field() {
        $api_key = esc_attr( get_option( 'yrkus_api_key' ) );
        echo '<input type="password" id="yrkus_api_key" name="yrkus_api_key" value="' . $api_key . '" class="regular-text" placeholder="sk_live_your_secret_key" />';
        echo '<p class="description">Visit the Yrkus API developer portal at 
      <a href="https://yrkus.com/api/">https://yrkus.com/api/</a></p>';
    }

    public function render_api_url_field() {
        $api_url = esc_attr( get_option( 'yrkus_api_url', 'https://www.yrk.us/api/links' ) );
        echo '<input type="url" id="yrkus_api_url" name="yrkus_api_url" value="' . $api_url . '" class="regular-text" />';
        echo '<p class="description">The API endpoint for creating links (default is correct).</p>';
    }

    // --- Asset Management ---

    // --- Asset Management ---

    public function enqueue_admin_assets($hook) {
        // Only load our assets on post/page edit screens or our settings page
        // MODIFIED: Also load on edit.php to handle the list table
        if ( 'post.php' != $hook && 'post-new.php' != $hook && strpos( $hook, 'edit.php' ) === false && strpos( $hook, 'yrkus-settings' ) === false ) {
            return;
        }

        // Enqueue CSS for styling the meta box
        wp_enqueue_style( 'yrkus-admin-css', YRKUS_PLUGIN_URL . 'admin/yrkus-admin.css', array(), '1.1' );

        // Enqueue JavaScript for API calls
        // MODIFIED: Changed version from 1.2 to 1.3 to force cache bust
        wp_enqueue_script( 'yrkus-shortener-js', YRKUS_PLUGIN_URL . 'admin/yrkus-shortener.js', array( 'jquery' ), '1.3', true );

        // Localize script to pass PHP variables to JavaScript
        wp_localize_script( 'yrkus-shortener-js', 'Yrkus_Admin_Vars', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'yrkus_nonce_action' )
        ));
    }

    // --- Meta Box UI ---

    public function add_shortlink_meta_box() {
        $screens = array( 'post', 'page' );
        foreach ( $screens as $screen ) {
            add_meta_box(
                'yrkus_shortlink_box',
                'Yrkus Short Link',
                array( $this, 'render_shortlink_meta_box' ),
                $screen,
                'side',
                'high'
            );
        }
    }

    // NEW: Function to retrieve the stored short link
    private function get_stored_short_link($post_id) {
        return get_post_meta($post_id, '_yrkus_short_link', true);
    }

    public function render_shortlink_meta_box($post) {
        $post_url = get_permalink($post->ID);
        $short_link = $this->get_stored_short_link($post->ID);
        $link_id = 'yrkus-link-output-' . $post->ID; // CRITICAL: Unique ID for meta box output

        ?>
        <div id="yrkus-shortlink-status">
            <p>Click below to generate a short link for this content.</p>
            
            <?php if ($short_link): ?>
                <!-- Always display if the link exists -->
                <p id="<?php echo esc_attr($link_id); ?>" class="yrkus-output-field">
                    <span class="dashicons dashicons-external"></span> Link Created: <br> 
                    <a href="<?php echo esc_url($short_link); ?>" target="_blank" class="yrkus-link-text"><?php echo esc_html($short_link); ?></a>
                    <button class="button button-small yrkus-copy-button" data-link-id="<?php echo esc_attr($link_id); ?>">
                        <span class="dashicons dashicons-admin-page"></span> Copy
                    </button>
                </p>
            <?php else: ?>
                <!-- Hide output field if no link exists -->
                <p id="<?php echo esc_attr($link_id); ?>" class="yrkus-output-field hidden"></p>
            <?php endif; ?>

            <p id="yrkus-error-message" class="yrkus-error-field hidden"></p>
            
            <button 
                id="yrkus-generate-button" 
                class="button button-primary button-large"
                data-post-url="<?php echo esc_url($post_url); ?>"
                data-post-id="<?php echo esc_attr($post->ID); ?>">
                Generate Yrkus Link
            </button>
            <p class="description">Post URL: <code><?php echo esc_url($post_url); ?></code></p>
        </div>
        <?php
    }

    // --- NEW: Post List Table Functions ---
    
    // Add new column header
    public function add_post_list_column($columns) {
        $new_columns = array();
        foreach ($columns as $key => $title) {
            $new_columns[$key] = $title;
            // Insert our new column after the title
            if ($key == 'title') { 
                $new_columns['yrkus_shortlink'] = 'Yrkus Short Link';
            }
        }
        return $new_columns;
    }

    // Render content for the new column
    public function render_post_list_column($column, $post_id) {
        if ($column == 'yrkus_shortlink') {
            $short_link = $this->get_stored_short_link($post_id);
            $link_id = 'yrkus-list-link-' . $post_id;

            if ($short_link) {
                ?>
                <div id="<?php echo esc_attr($link_id); ?>" class="yrkus-output-field">
                    <a href="<?php echo esc_url($short_link); ?>" target="_blank" class="yrkus-link-text"><?php echo esc_html($short_link); ?></a>
                    <button class="button button-small yrkus-copy-button" data-link-id="<?php echo esc_attr($link_id); ?>">
                        <span class="dashicons dashicons-admin-page"></span> Copy
                    </button>
                </div>
                <?php
            } else {
                // Display the "Generate" button only if the link hasn't been created
                ?>
                <button 
                    id="yrkus-generate-list-button-<?php echo esc_attr($post_id); ?>"
                    class="button button-small yrkus-generate-list-button"
                    data-post-url="<?php echo esc_url(get_permalink($post_id)); ?>"
                    data-post-id="<?php echo esc_attr($post_id); ?>">
                    Generate Link
                </button>
                <div id="yrkus-list-status-<?php echo esc_attr($post_id); ?>" class="yrkus-list-status"></div>
                <?php
            }
        }
    }

    // --- AJAX Handler (PHP Backend) ---

    public function ajax_generate_link() {
        // 1. Security Check
        check_ajax_referer( 'yrkus_nonce_action', 'security' );

        // 2. Get Configuration
        $api_key = get_option( 'yrkus_api_key' );
        $api_url = get_option( 'yrkus_api_url', 'https://www.yrk.us/api/links' );
        $post_url = sanitize_url( $_POST['post_url'] );
        $post_id = intval( $_POST['post_id'] ); // Get Post ID for saving

        if ( empty( $api_key ) || empty( $post_url ) ) {
            wp_send_json_error( array( 'message' => 'API Key or Post URL missing.' ) );
        }

        // 3. Build API Request Payload
        $payload = json_encode( array(
            'long_url' => $post_url,
            // Optional: You could add custom_slug here if you parse it from WP
            // 'custom_slug' => sanitize_title(get_the_title(url_to_postid($post_url))) 
        ) );

        // 4. Send Request to External API (yrk.us)
        $ch = curl_init( $api_url );
        curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
        curl_setopt( $ch, CURLOPT_POST, true );
        curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Authorization: Bearer ' . $api_key 
        ) );
        $response = curl_exec( $ch );
        $http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
        curl_close( $ch );

        // 5. Process API Response
        if ( $http_code === 201 ) {
            $data = json_decode( $response, true );
            $short_url = $data['short_url'];
            
            // --- NEW: Save the short link to post meta ---
            update_post_meta( $post_id, '_yrkus_short_link', esc_url_raw($short_url) );
            
            wp_send_json_success( array(
                'short_url' => $short_url,
                'message'   => 'Link successfully generated and saved.'
            ) );
        } else {
            // Attempt to get error message from API response
            $error_data = json_decode( $response, true );
            $error_message = 'API Error (Code: ' . $http_code . '). ';
            if ( isset( $error_data['error'] ) ) {
                $error_message .= $error_data['error'];
            } elseif ( !empty($response) ) {
                $error_message .= 'Response: ' . substr(strip_tags($response), 0, 100) . '...';
            } else {
                 $error_message .= 'Empty response from API.';
            }

            wp_send_json_error( array( 'message' => $error_message ) );
        }
    }
}